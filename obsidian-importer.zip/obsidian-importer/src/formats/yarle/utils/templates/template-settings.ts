export interface TemplateBlockSettings {
	template: string;
	check: Function;
	startBlockPlaceholder: string;
	endBlockPlaceholder: string;
	valuePlaceholder: string;
	value?: string;
}
