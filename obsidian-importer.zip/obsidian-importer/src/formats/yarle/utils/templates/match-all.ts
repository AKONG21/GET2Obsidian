export const MATCH_ALL = '(.|\r?\n)*';
export const MATCH_LF = '\r?\n?';
