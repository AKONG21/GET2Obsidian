export const CONTENT_PLACEHOLDER = '{updated-at}';
export const START_BLOCK = '{updated-at-block}';
export const END_BLOCK = '{end-updated-at-block}';
