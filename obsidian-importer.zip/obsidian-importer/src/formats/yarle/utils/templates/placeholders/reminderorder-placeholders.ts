export const CONTENT_PLACEHOLDER = '{reminder-order}';
export const START_BLOCK = '{reminder-order-block}';
export const END_BLOCK = '{end-reminder-order-block}';
