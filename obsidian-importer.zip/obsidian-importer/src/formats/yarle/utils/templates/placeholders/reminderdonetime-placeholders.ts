export const CONTENT_PLACEHOLDER = '{reminder-done-time}';
export const START_BLOCK = '{reminder-done-time-block}';
export const END_BLOCK = '{end-reminder-done-time-block}';
