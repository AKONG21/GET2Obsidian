export const CONTENT_PLACEHOLDER = '{content}';
export const START_BLOCK = '{content-block}';
export const END_BLOCK = '{end-content-block}';
