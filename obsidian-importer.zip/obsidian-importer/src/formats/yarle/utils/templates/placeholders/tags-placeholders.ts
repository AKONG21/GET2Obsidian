export const CONTENT_PLACEHOLDER = '{tags}';
export const START_BLOCK = '{tags-block}';
export const END_BLOCK = '{end-tags-block}';
