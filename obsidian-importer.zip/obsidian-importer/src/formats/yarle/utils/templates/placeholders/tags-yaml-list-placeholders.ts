export const CONTENT_PLACEHOLDER = '{tags-yaml-list}';
export const START_BLOCK = '{tags-yaml-list-block}';
export const END_BLOCK = '{end-tags-yaml-list-block}';
