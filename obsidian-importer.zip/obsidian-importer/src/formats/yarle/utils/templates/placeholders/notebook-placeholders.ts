export const CONTENT_PLACEHOLDER = '{notebook}';
export const START_BLOCK = '{notebook-block}';
export const END_BLOCK = '{end-notebook-block}';
