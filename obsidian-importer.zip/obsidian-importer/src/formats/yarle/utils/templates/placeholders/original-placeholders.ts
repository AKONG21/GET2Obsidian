export const CONTENT_PLACEHOLDER = '{link-to-original}';
export const START_BLOCK = '{link-to-original-block}';
export const END_BLOCK = '{end-link-to-original-block}';
