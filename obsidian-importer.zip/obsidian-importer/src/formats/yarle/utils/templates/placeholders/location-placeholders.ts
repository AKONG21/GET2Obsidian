export const CONTENT_PLACEHOLDER = '{location}';
export const START_BLOCK = '{location-block}';
export const END_BLOCK = '{end-location-block}';
