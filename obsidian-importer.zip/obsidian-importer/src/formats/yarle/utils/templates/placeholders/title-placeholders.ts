export const CONTENT_PLACEHOLDER = '{title}';
export const START_BLOCK = '{title-block}';
export const END_BLOCK = '{end-title-block}';
