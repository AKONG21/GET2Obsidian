export const START_BLOCK = '{metadata-block}';
export const END_BLOCK = '{end-metadata-block}';
