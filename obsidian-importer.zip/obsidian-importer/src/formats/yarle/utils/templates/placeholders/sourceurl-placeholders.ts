export const CONTENT_PLACEHOLDER = '{source-url}';
export const START_BLOCK = '{source-url-block}';
export const END_BLOCK = '{end-source-url-block}';
