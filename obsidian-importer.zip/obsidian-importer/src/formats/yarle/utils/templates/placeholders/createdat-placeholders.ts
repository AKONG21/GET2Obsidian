export const CONTENT_PLACEHOLDER = '{created-at}';
export const START_BLOCK = '{created-at-block}';
export const END_BLOCK = '{end-created-at-block}';
