export const CONTENT_PLACEHOLDER = '{reminder-time}';
export const START_BLOCK = '{reminder-time-block}';
export const END_BLOCK = '{end-reminder-time-block}';
