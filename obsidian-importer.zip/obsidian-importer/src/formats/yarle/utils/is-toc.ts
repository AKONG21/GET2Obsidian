export const isTOC = (noteTitle: any): boolean => {
	return noteTitle === 'Table of Contents';
};
