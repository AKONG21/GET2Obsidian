export const checkboxTodo = '- [ ]';
export const checkboxDone = '- [x]';
