declare module '@joplin/turndown-plugin-gfm' {
	const gfm: any;
}
