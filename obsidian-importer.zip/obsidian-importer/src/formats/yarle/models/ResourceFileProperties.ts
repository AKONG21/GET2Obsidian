export interface ResourceFileProperties {
	fileName: string;
	extension: string;
	index: string | number;
}
