export interface ResourceHashItem {
	fileName?: string;
	alreadyUsed?: boolean;
}
