export interface InternalLink {
	url: string;
	title: string;
	uniqueEnd: string;
}
