export interface TagSeparatorReplaceOptions {
	separatorInEN: string;
	replaceSeparatorWith: string;
	replaceSpaceWith?: string;
}
