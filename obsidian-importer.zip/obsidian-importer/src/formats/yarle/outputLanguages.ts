export const languageItems = {
	bold: '**',
	italic: '_',
	highlight: '==',
	strikethrough: '~~',
};
